package br.usjt.filaChamados;

import android.location.LocationListener;
import android.location.LocationManager;

public class Localizacao {

    private LocationManager locationManager;
    private LocationListener locationListener;

    locationManager = (LocationManager)
    getSystemService(Context.LOCATION_SERVICE);
    @Override
    public String toString() {
        return "Localizacao{" +
                "longitude=" + longitude +
                ", latitude=" + latitude +
                '}';
    }
}
